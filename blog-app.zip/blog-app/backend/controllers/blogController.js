const Blog = require('../models/blogModel');

const getBlogs = async (req, res) => {
  const blogs = await Blog.find();
  res.json(blogs);
};

const createBlog = async (req, res) => {
  const { title, content } = req.body;
  const blog = new Blog({ title, content });
  await blog.save();
  res.json(blog);
};

module.exports = { getBlogs, createBlog };