import React, { useEffect, useState } from 'react';
import { getBlogs } from '../services/blogService';
import Blog from '../components/Blog';

const Home = () => {
  const [blogs, setBlogs] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getBlogs();
      setBlogs(data);
    };
    fetchData();
  }, []);

  return (
    <div>
      {blogs.map(blog => <Blog key={blog._id} {...blog} />)}
    </div>
  );
};

export default Home;