import axios from 'axios';

export const getBlogs = async () => {
  const res = await axios.get('http://localhost:5000/api/blogs');
  return res.data;
};

export const createBlog = async (blog) => {
  const res = await axios.post('http://localhost:5000/api/blogs', blog);
  return res.data;
};